This dali installs into the correct place so you just need to do 

var dali = require('dali')(options)

instead of

var dali = require('/usr/lib..... dali)

