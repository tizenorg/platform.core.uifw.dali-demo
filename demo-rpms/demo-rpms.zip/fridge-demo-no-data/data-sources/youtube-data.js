// Simple youtube client the uses googleapis to search for
// videos, and return an array of video snippets ( thumbnail)
var https = require('https');
var HttpsProxyAgent = require('https-proxy-agent');

var proxyAgent = null;
//var url = require('url');

// see https://developers.google.com/youtube/v3/docs/search/list#http-request
// for a list of parameters that can be sent in the request
// q == query

function search(requestOptions, internetProxy, userCallback) {    

    var options = {
        hostname: 'www.googleapis.com',
        port: 443,
        path: '/youtube/v3/search?part=snippet&key=AIzaSyA8XfUkbpZNgofHJhPaUfnRUlgsejqHtfg',
        method: 'GET'
    }

    // cycle through all the options and add them to the path string
    for (var key in requestOptions) {
        options.path += "&" + key + "=" +encodeURIComponent(requestOptions[key]);
    }

    //var endpoint = optons.path;
    //var opts = url.parse(endpoint);
    if( internetProxy )
    {
        if( ! proxyAgent )
        {
            proxyAgent = new HttpsProxyAgent( internetProxy );   
        }
        options.agent = proxyAgent;
    }

    //console.log("options"+ options.path);


    var req = https.request(options, function(res) {
        console.log("statusCode: ", res.statusCode);
        console.log("headers: ", res.headers);
        var data = "";
        res.on('data', function(chunk) {
            data+=chunk;
        });

        res.on('end', function() {
            userCallback( data );
            console.log("finished");
        });
    }).on('error', function(e) {
        console.log("Got error: " + e.message);
    });

    req.end();

}

module.exports.search = search;