
var youKuAPI = require('./youku-data.js');
 

function YouKuApp( )// constructor
{

    var LAYOUT =
    {
        rowSpacing:40,
        thumbPosition:[10,50,0],
        titlePosition:[200,40,0],
       // shrink thumbnail to 66%
        thumbSize:[320*(2/3),180*(2/3),0]
    };

    this.mycallback = function( data )
    {
        try
        {
//            console.log(data);
            var object = JSON.parse(data);
            var videos = object.videos;
            // add a delay to the fade on for each animation 
            var animOptions = {
               alpha: "easeInOutSine",
                delay: 0,
                duration: 1.0,
            };

            for( i = 0; i< videos.length;++i)
            {
                var container = this.items[i];
                // should really switch to get child by name
                var thumbnail = container.getChildAt(0);
                var titleContainer = container.getChildAt(1);
                var title = titleContainer.getChildAt(0);

//                console.log( videos[i].title);
//                console.log( videos[i].thumbnail);

                var image  = new this.dali.ResourceImage( {url:videos[i].thumbnail } );
                thumbnail.size = LAYOUT.thumbSize;
                thumbnail.setImage( image );
                title.text = videos[i].title;

                container.color = [ 1, 1, 1, 0];
                var anim = new this.dali.Animation( 1 );
                anim.animateBy( container, "color", [ 1, 1, 1, 1] , animOptions);
                animOptions.delay +=0.2; // delay by 1/3 second to account for loading time
                anim.play();
            }
        }
        catch(e)
        {
            console.log("Invalid data from server: " + e);
        }
    };
    this.search = function( keyword  )
    {
        // Use multiple client ids to avoid error of rate limiting access for single id
        // See error code 1017 from http://open.youku.com/docs?id=142
        var client_ids = ['db28698382d53e23',
                          '6f0c6f5ab70fe63b',
                          'e8066412aa60d453',
                          '4245aa5705cfcf21',
                          'c9bb14f8593c7a8b',
                          '18e2001aeecf0c0f',
                          '6c1c8a9ed1e2fcb9',
                          '73aaf9a2724754a0',
                          '8afc1bdf9487f339',
                          '0dec1b5a3cb570c1'];

        var client_id = client_ids[Math.round( Math.random() * (client_ids.length - 1) )];

        // use http://open.youku.com/docs?id=81
        // for testing out what options you want to set
        var searchOptions = {
            keyword:keyword,
            count:this.numberItems,
            client_id:client_id
//            peorid:'week'
        }
        //console.log("searching");
        // create a closure
        var that = this;

        youKuAPI.search( searchOptions, this.proxy, function(data)  {
            that.mycallback(data);
            });
    };

    this.createItem = function()
    {
        // just create a thumbnail for now and title
        var container = new this.dali.Actor();
        container.parentOrigin = this.dali.TOP_LEFT;
        container.anchorPoint = this.dali.TOP_LEFT;

        var thumbnail = new this.dali.ImageActor();

        thumbnail.parentOrigin = this.dali.TOP_LEFT;
        thumbnail.anchorPoint = this.dali.TOP_LEFT;
        thumbnail.position= LAYOUT.thumbPosition; // inset
        thumbnail.name = "thumbnail";

        var titleContainer = new this.dali.Actor();
        titleContainer.parentOrigin = this.dali.TOP_LEFT;
        titleContainer.anchorPoint = this.dali.TOP_LEFT;
        titleContainer.positionX = LAYOUT.thumbSize[0] + 20;
        titleContainer.positionY = LAYOUT.thumbPosition[1];
        titleContainer.size = LAYOUT.thumbSize; // currently use same size as thumbnail for text

        var title = new this.dali.Control("TextLabel");
        title.fontFamily ="HelveticaNeue";
        title.fontStyle = "Bold";

        title.parentOrigin = this.dali.TOP_LEFT;
        title.anchorPoint = this.dali.TOP_LEFT;
        title.textColor = [0.1,0.1,0.1,1.0]; //grey
        title.multiLine = true;
        title.widthResizePolicy = "FILL_TO_PARENT";
        title.heightResizePolicy = "DIMENSION_DEPENDENCY";
        title.pointSize = 13;

        title.name = "title";
        titleContainer.add( title );

        container.add( thumbnail );
        container.add( titleContainer );

        return container;
    }
    this.createItemList = function()
    {
        this.items = [];
        var yPos = 0;
        for( var i = 0; i < this.numberItems; ++i )
        {
            var item = this.createItem(i);
            item.positionY = yPos;
            this.placeHolder.add( item );
            this.items.push( item );
            yPos+=LAYOUT.thumbSize[1] + LAYOUT.rowSpacing;
        }
    }

    this.createUI =function ( daliObject, internetProxy, imageDir ) 
    {
       this.numberItems = 5; 
       this.dali = daliObject;
       this.proxy = internetProxy;
       var image = new this.dali.ResourceImage( {url: imageDir + "white-pixel.png"} );
       this.placeHolder = new this.dali.ImageActor( image );
       this.placeHolder.positionY = 10;

       var logo = new this.dali.ResourceImage( {url: imageDir + "youku.png"} );
       var logoActor = new this.dali.ImageActor(logo);
       logoActor.parentOrigin = this.dali.TOP_LEFT;
       logoActor.anchorPoint = this.dali.TOP_LEFT;
       logoActor.positionX = 20;
       this.placeHolder.add( logoActor );

       this.createItemList();

       return this.placeHolder;
    };
};


// may youku app a singleton so any other JavaScript file can use it
module.exports = new YouKuApp();
