// Fridge demo application
//var youTube = require('./data-sources/youtube-app.js')
//var youKu = require('./data-sources/youku-app.js') // NO DATA UNCOMMENT FOR DATA

// If using a proxy set the ip address here
//var internetProxy = "http://106.1.18.35:8080"
 var internetProxy = ""

var window= {
       x:0,
       y:0,
       width:1920,
       height: 1080,
       transparent: false,
       name:'dali-fridge-app'
 };

var viewMode={
       'stereoscopic-mode':'mono', // stereo-horizontal, stereo-vertical, stereo-interlaced,
       'stereo-base': 65 // Distance in millimeters between left/right cameras typically between (50-70mm)
 };

var options= {
       'window': window,
       'view-mode': viewMode,
 }
 //var dali = require('../build/Release/dali')( options );
 var dali = require('/usr/lib/node_modules/npm/node_modules/dali/dali')( options );

var imageDir = "./images/";
var scriptDir = "./scripts/";
 
var fridgeApp = { };

/**
 * Initialises the image paths and creates a builder for loading JSON
 * @method init
 */
fridgeApp.init = function()
{
  console.log("Image directory is : " + imageDir);
  console.log("JSON Script directory is : " + scriptDir);

  this.builder = new dali.Builder();
  this.builder.addConstants({
      IMAGE_PATH: imageDir,
      SCRIPT_PATH: scriptDir
  });

  this.builder.loadFromFile(scriptDir + "main-screen.json");
}

fridgeApp.createBackground = function( fileName )
{
  // create a background image
  var stageSize = dali.stage.getSize();
  this.stageSize = [stageSize.x, stageSize.y, 1];

  var image = new dali.ResourceImage( {url: imageDir + fileName} );
  var background = new dali.ImageActor(image);
  background.parentOrigin = dali.TOP_LEFT;
  background.anchorPoint = dali.TOP_LEFT;
  background.position = [0.0,0.0,-4.0];
  background.size = [stageSize.x,stageSize.y,0.0];

  //Add background to the stage
  dali.stage.add( background );
}

fridgeApp.createPosters = function()
{
  //Create scroll view
  var scrollviewFactory = require("./scrollview.js");
  var stageSize = dali.stage.getSize();

  var itemSize = [stageSize.x/4.0, stageSize.y * 0.85,0.0];
  this.posters = scrollviewFactory.New("Posters", itemSize, 0.0, dali);
  this.posters.root.position = [0.0,stageSize.y * 0.15,-2.0];
  dali.stage.add( this.posters.root );

  for(var i = 0; i < 4; i++)
  {
    if( i == 1000) // NO_DATA, change to 0 to enable
    
      // to do we can pass in search options here?
      var item = youKu.createUI( dali, internetProxy, imageDir );
      youKu.search("films");
      this.posters.addItem( item );    
    }
    else
    {
      var image = new dali.ResourceImage( {url: imageDir + "item0.png"} );
      var item = new dali.ImageActor(image);
      this.posters.addItem(item);
    }
    image = new dali.ResourceImage( {url: imageDir + "item1.png"} );
    item = new dali.ImageActor(image);
    this.posters.addItem(item);

    image = new dali.ResourceImage( {url: imageDir + "item2.png"} );
    item = new dali.ImageActor(image);
    this.posters.addItem(item);

    image = new dali.ResourceImage( {url: imageDir + "item3.png"} );
    item = new dali.ImageActor(image);
    this.posters.addItem(item);

    image = new dali.ResourceImage( {url: imageDir + "item4.png"} );
    item = new dali.ImageActor(image);
    this.posters.addItem(item);

    image = new dali.ResourceImage( {url: imageDir + "item5.png"} );
    item = new dali.ImageActor(image);
    this.posters.addItem(item);
  }

  this.posters.itemRoot.size = [stageSize.x,stageSize.y*0.85,0.0];
  this.posters.itemRoot.parentOrigin = dali.TOP_LEFT;
  this.posters.itemRoot.anchorPoint = dali.TOP_LEFT;
  this.posters.itemRoot.name = "posters";
}

fridgeApp.createBanner = function()
{
  //Create banner
  var stageSize = dali.stage.getSize();
  var image = new dali.ResourceImage({url: imageDir + "banner.png"} );
  var bannerFactory = require("./banner.js");
  this.banner = bannerFactory.New(image,[0.0,0.0,-3.0],[stageSize.x,stageSize.y*0.15,0], dali);

  dali.stage.add( this.banner.root );
}

function scalePointSize( pointSize )
{
  var dpi = dali.stage.getDpi();
  var meanDpi = (dpi.x + dpi.y) * 0.5;
  return pointSize * 220 / meanDpi;
}

function createMenuItem( itemSize, iconName, title, fontSize )
{
  fridgeApp.builder.addConstants({
      MENU_ITEM_SIZE_X:itemSize[0],
      MENU_ITEM_SIZE_Y:itemSize[1],

      MENU_ITEM_ICON: iconName,
      MENU_ITEM_TITLE: title
  });

  var item = fridgeApp.builder.create({template: "template-menu-item"});
  var icon = item.findChildByName("icon");
  icon.size = [itemSize[0]*0.5,itemSize[0]*0.5,0.0];
  icon.position = [0.0,-itemSize[1]*0.1,0.0];

  var text = icon.findChildByName("title");
  text.position = [0.0,itemSize[0]*0.1,0.0];
 

  var line = item.findChildByName("line");
  line.size = [1.0,itemSize[1],0.0];

  return item;
}

fridgeApp.createMenu = function()
{
  var stageSize = dali.stage.getSize();
  var scrollviewFactory = require("./scrollview.js");
  var itemSize = [stageSize.x/8.0,stageSize.y*0.25,0.0];
  this.menu = scrollviewFactory.New("Menu", itemSize, 0.0, dali);
  this.menu.root.position = [0,stageSize.y*0.75,0.0];
  dali.stage.add( this.menu.root );

  for(var i = 0; i < 10; i++)
  {
    var menuItem = createMenuItem(itemSize,"icon0.png","Weather",18);
    this.menu.addItem(menuItem);

    menuItem = createMenuItem(itemSize,"icon1.png","Quotes",18);
    this.menu.addItem(menuItem);

    menuItem = createMenuItem(itemSize,"icon2.png","Movie",18);
    this.menu.addItem(menuItem);
  }

  this.menu.hide(stageSize.y*0.25,0.0,0.0);

  //Create menu background effect
  var menuBackgroundfactory = require("./menubackground.js");
  var image = new dali.ResourceImage( {url: imageDir + "white-pixel.png"} );
  var icon = new dali.ResourceImage( {url: imageDir + "arrow.png"} );
  this.menu.background = menuBackgroundfactory.New(fridgeApp, [0.0,stageSize.y*0.75,-1.0],[stageSize.x,stageSize.y*0.25,0.0], image, icon, [stageSize.x*0.02,stageSize.y*0.025,0.0], 0.02, dali );
  dali.stage.add( this.menu.background.actor );

  this.isMenuVisible = false;

  this.menu.itemRoot.size = [stageSize.x,stageSize.y*0.25,0.0];
  this.menu.itemRoot.parentOrigin = dali.TOP_LEFT;
  this.menu.itemRoot.anchorPoint = dali.TOP_LEFT;
  this.menu.itemRoot.name = "menu";
}

function startup()
{
  fridgeApp.init();
  dali.stage.connect("key-event", fridgeApp.stageKeyEvent);
  dali.keyboardFocusManager.connect("keyboard-pre-focus-change", fridgeApp.preFocusChanged);
  fridgeApp.createBackground("background.png");

  fridgeApp.createPosters();
  fridgeApp.createBanner();
  fridgeApp.createMenu();
}

fridgeApp.showMenu = function()
{
  var stageSize = dali.stage.getSize();
  var postersViewSize = [stageSize.x, (stageSize.y*0.8)*0.85,0.0];
  var itemSize = [(stageSize.x/4.0)*0.85, (stageSize.y*0.8)*0.85,0.0];
  var posterPositionY = 0.15*stageSize.y - (0.75-0.8*0.85)*stageSize.y*0.5;
  fridgeApp.posters.expand(-posterPositionY, postersViewSize, itemSize, 0.5, 0.0);
  fridgeApp.banner.hide(0.2,0.0);

  fridgeApp.menu.background.show(1.0,0.3);
  fridgeApp.menu.show(0.5,0.8,0.05);
  fridgeApp.isMenuVisible = true;
  fridgeApp.isFocusInPosters = false;
  fridgeApp.menu.focus(0,0.0,0.0);
}

fridgeApp.hideMenu = function()
{
  var stageSize = dali.stage.getSize();
  fridgeApp.menu.background.hide(1.0,0.0);
  fridgeApp.menu.hide(stageSize.y*0.25,0.5,0.0);

  var postersViewSize = [stageSize.x, stageSize.y*0.85, 0.0];
  var itemSize = [(stageSize.x/4.0), (stageSize.y*0.85),0.0];
  fridgeApp.posters.expand(0, postersViewSize, itemSize, 0.5, 0.8);
  fridgeApp.banner.show(0.2,0.8);
  fridgeApp.isMenuVisible = false;
  fridgeApp.isFocusInPosters = true;
}

fridgeApp.stageKeyEvent = function(keyEvent) {
  if( keyEvent.state == "up" )
    return;

  switch (keyEvent.keyDescription)
  {
    case "BackSpace":
    case "XF86Back":
    case "Escape":
    {
      if( fridgeApp.isMenuVisible )
      {
        fridgeApp.hideMenu();

        if(fridgeApp.posters.isFocused == false )
        {
          fridgeApp.posters.focus(fridgeApp.posters.focusedItem);
          fridgeApp.posters.isFocused = true;
        }
      }
      break;
    }
    case "XF86AudioForward":
    case "Next":
    {
      if(fridgeApp.posters.isFocused == true )
      {
        fridgeApp.posters.scroll( -dali.stage.getSize().x, 1.0, 0.05, fridgeApp.posters.getFirstVisibleItemId());
      }
      else if(fridgeApp.menu.isFocused == true )
      {
        fridgeApp.menu.scroll( -dali.stage.getSize().x, 1.0, 0.05,  fridgeApp.menu.getFirstVisibleItemId());
      }
      break;
    }
    case "XF86AudioRewind":
    case "Prior":
    {
      if(fridgeApp.posters.isFocused == true )
      {
        fridgeApp.posters.scroll( dali.stage.getSize().x, 1.0, 0.05, fridgeApp.posters.getLastVisibleItemId());
      }
      else if(fridgeApp.menu.isFocused == true )
      {
        fridgeApp.menu.scroll( dali.stage.getSize().x, 1.0, 0.05, fridgeApp.menu.getLastVisibleItemId());
      }
      break;
    }
  }
}

fridgeApp.preFocusChanged = function(currentFocusedActor, proposedActorToFocus, direction)
{
  if (direction == "up" )
  {
    if(fridgeApp.posters.isFocused == false)
    {
        fridgeApp.posters.isFocused = true;
        return fridgeApp.posters.focus(fridgeApp.posters.getFirstVisibleItemId(),0.0,0.0);
    }
  }
  else if (direction == "down")
  {
      if(fridgeApp.posters.isFocused == true)
      {
        if( fridgeApp.isMenuVisible == false )
        {
          fridgeApp.showMenu();
        }
        else
        {
          fridgeApp.menu.focus(fridgeApp.menu.getFirstVisibleItemId(),0.0,0.0);
        }

        fridgeApp.posters.isFocused = false;
        return fridgeApp.menu.focusedActor();
      }
  }
  else if (direction == "left")
  {
    if( fridgeApp.posters.isFocused == true )
    {
      return fridgeApp.posters.focusPrev();
    }
    else
    {
      return fridgeApp.menu.focusPrev();
    }
  }
  else if (direction == "right")
  {
    if( fridgeApp.posters.isFocused == true )
    {
      return fridgeApp.posters.focusNext();
    }
    else
    {
      if( fridgeApp.isMenuVisible == true)
      {
        return fridgeApp.menu.focusNext();
      }
      else
      {
       fridgeApp.posters.isFocused = true;
      }
    }
  }

  return currentFocusedActor;
}

var currentSearchIndex = 1; // we start at 0;
setInterval(function() { 
var searchTerms = [
  "Films",
  "cats",
  "breaking News",
  "Latest Sport",
  "Minecraft" 
]
  // NO_DATA uncomment below
 //youKu.search( searchTerms[currentSearchIndex]);
 currentSearchIndex++;
 if( currentSearchIndex === searchTerms.length )
 {
  currentSearchIndex=0;
 }
}, 10000);


startup();
