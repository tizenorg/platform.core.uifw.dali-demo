
exports.New = function( image, position, size, dali )
{
  var result =
  {
    "dali":dali,
    "root": new dali.ImageActor(image),
    "ShowAnimation":null,
    "HideAnimation":null,

    show : function(duration,delay)
    {
      var progress = 0.0;
      if(this.HideAnimation)
      {
        progress = this.HideAnimation.getCurrentProgress();
        if( progress != 0.0 )
          progress = 1.0-progress;

        this.HideAnimation.stop();
      }

      var animOptions = { alpha:"linear", delay:delay, duration:duration};
      this.ShowAnimation = new dali.Animation(duration+delay);
      this.ShowAnimation.animateTo( this.root, "color-alpha", 1.0, animOptions );
      this.ShowAnimation.playFrom(progress);
    },

    hide : function(duration,delay)
    {
      var progress = 0.0;
      if( this.ShowAnimation )
      {
        progress = this.ShowAnimation.getCurrentProgress();
        if( progress != 0.0 )
          progress = 1.0-progress;

        this.ShowAnimation.stop();
      }

      var animOptions = { alpha:"linear", delay:delay, duration:duration};
      this.HideAnimation = new dali.Animation(duration+delay);
      this.HideAnimation.animateTo( this.root, "color-alpha", 0.0, animOptions );
      this.HideAnimation.playFrom(progress);
    }
  }

  result.root.parentOrigin = dali.TOP_LEFT;
  result.root.anchorPoint = dali.TOP_LEFT;
  result.root.size = size;
  result.root.position = position;

  return result;
}
