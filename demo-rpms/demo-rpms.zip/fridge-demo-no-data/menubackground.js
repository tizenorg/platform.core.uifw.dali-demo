
var applicationInstance;

exports.New = function( application, position, size, backgroundImage, iconImage, iconSize, circleDefaultRadius, dali )
{
  var result =
  {
    "actor": new dali.ImageActor(backgroundImage),
    "shader":null,
    "showAnimation":null,
    "hideAnimation":null,
    "circleDefaultRadius":circleDefaultRadius,
    "arrow":new dali.ImageActor(iconImage),
    "visible":false,

    show : function(duration,delay)
    {
      var progress = 0.0;
      if( this.hideAnimation )
      {
        progress = this.hideAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0-progress;

        this.hideAnimation.stop();
      }
      this.showAnimation = new dali.Animation(duration);
      var animOptions = { alpha:"easeInOutSine", delay:delay, duration:duration};

      this.showAnimation.animateTo( this.shader, "uCircleRadius", 1.0, animOptions );
      this.showAnimation.animateTo( this.shader, "uColor", [1.0,1.0,1.0,1.0], animOptions );

      animOptions = { alpha:"linear", delay:delay, duration:duration*0.5};
      this.showAnimation.animateTo( this.arrow, "color-alpha", 0.0, animOptions );
      this.showAnimation.setSpeedFactor(1.0);
      this.showAnimation.playFrom(progress);

      this.visible = true;
    },

    hide : function(duration,delay)
    {
      var progress = 0.0;
      if( this.showAnimation )
      {
        progress = this.showAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0-progress;

        this.showAnimation.stop();
      }
      this.hideAnimation = new dali.Animation(duration);
      var animOptions = { alpha:"easeInOutSine", delay:delay, duration:duration};

      var keyFramesRadius = [{progress:0.0, value: 1.0},{progress:1.0, value:this.circleDefaultRadius }];
      var keyFramesColor = [{progress:0.0, value: [1.0,1.0,1.0,0.0]},{progress:1.0, value:[0.0,0.0,0.0,0.0]}];

      this.hideAnimation.animateTo( this.shader, "uCircleRadius", circleDefaultRadius, animOptions );
      this.hideAnimation.animateTo( this.shader, "uColor", [0.0,0.0,0.0,1.0], animOptions );

      animOptions = { alpha:"linear", delay:delay, duration:duration};
      this.hideAnimation.animateTo( this.arrow, "color-alpha", 1.0, animOptions );
      this.hideAnimation.setSpeedFactor(1.0);
      this.hideAnimation.playFrom(progress);

      this.visible = false;
    },

    arrowTouchedEvent : function(actor, touchEvent)
    {
      if (touchEvent.points[0].state == "down")
      {
        applicationInstance.showMenu();
      }
      return true;
    }
  }

  result.actor.parentOrigin = dali.TOP_LEFT;
  result.actor.anchorPoint = dali.TOP_LEFT;
  result.actor.size = size;
  result.actor.position = position;
  result.actor.setBlendMode(2);

  var vertShader =
      "uniform lowp vec3 uSize;\
       uniform lowp vec2 uCircleCenter;\
       varying lowp vec2 vPointToCenter;\
       void main()\
       {\
         gl_Position = uProjection * uModelView * vec4(aPosition, 1.0);\
         vPointToCenter = vec2( vec2(aTexCoord.x,(uSize.y/uSize.x)*aTexCoord.y + (abs(uSize.x-uSize.y)*0.5)/uSize.x) -  uCircleCenter);\
         vTexCoord = aTexCoord;\
       }"

  var fragShader =
      " uniform lowp float uCircleRadius;\
        varying lowp vec2 vPointToCenter;\
        void main()\
        {\
          lowp float distanceToSphere = sqrt(dot(vPointToCenter,vPointToCenter)) - uCircleRadius;\
          lowp float alpha = min(0.5,-distanceToSphere*1000.0 + 1.0);\
          gl_FragColor = vec4( texture2D( sTexture, vTexCoord ).xyz * uColor.xyz, alpha);\
        }"

      var shaderOptions = {
          geometryType: "image",
          vertexShader : vertShader,
          fragmentShader: fragShader
      };


      var shaderOptions = {
          geometryType: "image",
          vertexShader : vertShader,
          fragmentShader: fragShader
      };

  // create a new shader effect
  result.shader = new dali.ShaderEffect(shaderOptions);

  // set the uniforms
  result.shader.setUniform("uColor",[0.0,0.0,0.0,0.0]);
  result.shader.setUniform("uSize",size);
  result.shader.setUniform("uCircleRadius",result.circleDefaultRadius);
  result.shader.setUniform("uCircleCenter",[0.5, ((0.5*size[1])/size[0]) + 0.5]);
  result.actor.setShaderEffect(result.shader);

  result.arrow.parentOrigin = dali.BOTTOM_CENTER;
  result.arrow.anchorPoint = dali.BOTTOM_CENTER;
  result.arrow.size = iconSize;
  result.arrow.setBlendMode(2);
  result.actor.add(result.arrow);
  result.arrow.connect("touched", result.arrowTouchedEvent);

  instance = result;
  applicationInstance = application;

  return result;
}
