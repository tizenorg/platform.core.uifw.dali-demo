
Pure Wayland demo ( tested on LibUV / Node.JS)


Built from following repos

dali-core 1.1.1
774aeaa9da6bc7f693a61d65f8010a57fd11daf9-->Merge "Fix VD prevent issues - DIVIDE_BY_ZERO
----------------------------
dali-adaptor 1.1.1
https://review.tizen.org/gerrit/#/c/47361/

a810bac35b57db35e555040df2a3e94fc0c1ab2a-->Prototype pure wayland adaptor for DALi-
/b0c9acfa79045f3ebac4978ba5a24a62ec536c5a-->Merge "Fix VD prevent issues" into devel/master--
----------------------------
dali-toolkit 1.1.1

https://review.tizen.org/gerrit/#/c/43973/

39367b1e985d2293c9aa28a9712fb08d3f0bd6ba-->DALi node addon spec file for GBS build

2047844bb3b4a84231905c8c540d34d4c468e5ad-->Merge "Fix prevent issues" into devel/master-->Adeel Ka



