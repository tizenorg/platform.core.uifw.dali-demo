#!/bin/sh 
cd /usr/lib/node/examples/fridge/
node fridge-app.js
