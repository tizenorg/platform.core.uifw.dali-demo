
var scrollViewInstance = {};
var scrollViewInstanceCount = 0;

exports.New = function( name, itemSize, padding, dali, fridgeApp )
{
  var result =
  {
    //Member variables
    "dali":dali,
    "fridgeApp":fridgeApp,
    "name":name,
    "itemCount":0,
    "itemSize":itemSize,
    "root":new dali.Actor(),
    "itemRoot":null,
    "item":[],
    "expandAnimation":null,
    "scrollAnimation":{},
    "scrollCount":0,
    "padding":padding,
    "showAnimation":null,
    "hideAnimation":null,
    "isFocused":false,
    "focusedItem":-1,
    "panGestureDetector":null,
    "currentScrollPosition":0.0,
    "scrollDisplacementX":0.0,
    "scrollDisplacementY":0.0,
    "baseItem":null,

    getPosition : function( id, scroll )
    {
      return [(this.itemSize[0]*id + this.padding*(id+1)) + scroll, 0.0, 0.0];
    },

    getFirstVisibleItemId : function ()
    {
      return Math.floor(-1.0 * this.currentScrollPosition / this.itemSize[0]);
    },

    getLastVisibleItemId : function ()
    {
      return Math.ceil((dali.stage.getSize().x - this.currentScrollPosition) / this.itemSize[0] - 1);
    },

    //API
    addItem : function( actor )
    {
      if(this.itemRoot == null )
      {
        this.itemRoot = new dali.Actor();
        this.root.add(this.itemRoot);
        this.enablePanGetureDetection();
      }

      actor.parentOrigin = dali.TOP_LEFT;
      actor.anchorPoint = dali.TOP_LEFT;
      actor.size = this.itemSize;
      actor.setKeyboardFocusable(true);
      actor.on("hovered", this.onHover);
      actor.position = this.getPosition(this.itemCount, this.currentScrollPosition);
      var itemName = name + this.itemCount;
      actor.name = itemName;
      this.itemRoot.add( actor );
      this.item[this.itemCount] = actor;
      this.panGestureDetector.attach(actor);
      this.itemCount++;
    },

    expand : function( translation, targetViewSize, targetItemSize, duration, delay )
    {
      var progress=0.0;
      if(this.expandAnimation)
      {
        progress = this.expandAnimation.getCurrentProgress();
        if(progress > 0.0 )
          progress = 1.0-progress;

         this.expandAnimation.stop();
      }
      this.expandAnimation = new dali.Animation(duration+delay);

      var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:delay, duration:duration};

      var scale = [targetItemSize[0]/this.itemSize[0], targetItemSize[1]/this.itemSize[1], 1.0];
      for( i=0; i<this.item.length; ++i )
        this.expandAnimation.animateTo( this.item[i], "scale", scale, animOptions );

      var stageSize = dali.stage.getSize();
      this.expandAnimation.animateTo( this.itemRoot, "size", targetViewSize, animOptions );
      this.expandAnimation.animateTo( this.itemRoot, "positionY", translation, animOptions );
      this.expandAnimation.playFrom(progress);
    },

    stopScrollAnimation : function()
    {
      var animCount = this.scrollAnimation.length;
      for( i=0; i<animCount; ++i )
      {
        this.scrollAnimation[i].stop();
        this.scrollAnimation[i].clear();
      }

       this.scrollAnimation = [];
       this.scrollCount = 0;
    },
    scroll : function( amount, duration, itemDelay, baseItem )
    {
      // Clamp the target scroll position
      var tagetScrollPosition = this.currentScrollPosition + amount;
      var totalItemSize = this.item.length * this.itemSize[0];
      var stageSize = dali.stage.getSize();
      var maxScrollPosition = stageSize.x - totalItemSize;
      if( tagetScrollPosition < maxScrollPosition)
      {
        tagetScrollPosition = maxScrollPosition;
      }
      if( tagetScrollPosition > 0.0 )
      {
        tagetScrollPosition = 0.0;
      }

      this.stopScrollAnimation();
      this.scrollAnimation[this.scrollCount] = new dali.Animation(duration);
      if(duration > 0)
      {
        for( i=0; i<this.item.length; ++i )
        {
          var currentPosition = this.item[i].position;
          var targetPosition = this.getPosition(i, tagetScrollPosition);
          var keyFramesPosition = [{progress:0.0, value: currentPosition},
                                   {progress:1.0, value:targetPosition}
                                  ];

          var delay = 0.0;
          if( amount < 0.0 && i >= baseItem )
          {
            delay = (i - baseItem)*itemDelay;
          }
          else if( amount > 0.0 && i <= baseItem )
          {
            delay = (baseItem- i)*itemDelay;
          }

          var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_OUT_SINE, delay:delay, duration:duration};
          this.scrollAnimation[this.scrollCount].animateTo( this.item[i], "position", targetPosition, animOptions );
        }

        this.currentScrollPosition = tagetScrollPosition;
        this.scrollAnimation[this.scrollCount].play();
      }
      else
      {
        for( i=0; i<this.item.length; ++i )
        {
          var targetPosition = this.getPosition(i, tagetScrollPosition);
          this.item[i].position = targetPosition;
        }
        this.currentScrollPosition = tagetScrollPosition;
      }

      this.scrollCount++;
    },
    scrollcontinue : function( amount, duration, itemDelay, baseItem )
    {
      // Clamp the target scroll position
      var tagetScrollPosition = this.currentScrollPosition + amount;
      var totalItemSize = this.item.length * this.itemSize[0];
      var stageSize = dali.stage.getSize();
      var maxScrollPosition = stageSize.x - totalItemSize;
      if( tagetScrollPosition < maxScrollPosition)
      {
        tagetScrollPosition = maxScrollPosition;
      }
      if( tagetScrollPosition > 0.0 )
      {
        tagetScrollPosition = 0.0;
      }

      if(duration > 0)
      {

        this.scrollAnimation[this.scrollCount] = new dali.Animation(duration);

        for( i=0; i<this.item.length; ++i )
        {
          var currentPosition = this.item[i].position;
          var targetPosition = this.getPosition(i, tagetScrollPosition);
          var keyFramesPosition = [{progress:0.0, value: currentPosition},
                                   {progress:1.0, value:targetPosition}
                                  ];

          var delay = 0.0;
          var animDuration = duration
          if( amount < 0.0 )
          {
            if( i < baseItem )
            {
              animDuration = Math.max(0.0, duration + 5.0*(i-baseItem)*itemDelay );
            }
            else
            {
              delay = (i - baseItem)*itemDelay;
            }
          }
          else if( amount > 0.0 )
          {
            if( i <= baseItem )
              delay = (baseItem- i)*itemDelay;
            else
            {
              animDuration = Math.max(0.0, duration - 5.0*(i-baseItem)*itemDelay );
            }
          }

          var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_OUT_SINE, delay:delay, duration:animDuration};
          this.scrollAnimation[this.scrollCount].animateTo( this.item[i], "position", targetPosition, animOptions );
        }

        this.currentScrollPosition = tagetScrollPosition;
        this.scrollAnimation[this.scrollCount].play();
      }
      else
      {
        for( i=0; i<this.item.length; ++i )
        {
          var targetPosition = this.getPosition(i, tagetScrollPosition);
          this.item[i].position = targetPosition;
        }
        this.currentScrollPosition = tagetScrollPosition;
      }
      this.scrollCount++;
    },

    show : function( duration, delay, itemDelay )
    {
      var progress = 0.0;
      if( this.hideAnimation )
      {
        progress = this.hideAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0 - progress;
        this.hideAnimation.stop();
      }

      this.itemRoot.position = [0,0,0];
      this.showAnimation = new dali.Animation(duration);

      var keyFramesPosition = [{progress:0.0, value: this.itemRoot.position.y},
                                {progress:1.0, value:0.0}
                               ];

      var itemsOnScreen = dali.stage.getSize().x/this.itemSize[0];
      for( i=0; i<this.item.length; ++i )
      {
        var d = delay;
        if( i<itemsOnScreen )
        {
          d += itemDelay*i;
        }
        var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:d, duration:duration};
        this.showAnimation.animateBetween( this.item[i], "positionY", keyFramesPosition, animOptions );
        this.showAnimation.animateTo( this.item[i], "colorAlpha", 1.0, animOptions );

      }

      this.showAnimation.playFrom(progress);
   },

   hide : function(translation,duration,delay)
   {
      var progress = 0.0;
      if( this.showAnimation )
      {
        progress = this.showAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0 - progress;

        this.showAnimation.stop();
      }

      this.hideAnimation = new dali.Animation(duration);

      var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:delay, duration:duration};
      this.hideAnimation.animateTo( this.itemRoot, "positionY", translation, animOptions );

      for( i=0; i<this.item.length; ++i )
      {
        var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:delay, duration:duration};
        this.hideAnimation.animateTo( this.item[i], "colorAlpha", 0.0, animOptions );
      }

     this.hideAnimation.playFrom(progress);
   },

   focusNext : function()
   {
     var visibleRange = [this.getFirstVisibleItemId(), this.getLastVisibleItemId()];

     if( this.focusedItem < visibleRange[0] || this.focusedItem > visibleRange[1] )
     {
      this.focusedItem = visibleRange[0];
     }
     else if( this.focusedItem < this.item.length-1)
     {
       this.focusedItem++;
     }
     return this.focus(this.focusedItem, 0.2, 0.0);
   },

   focusPrev : function()
   {
     var visibleRange = [this.getFirstVisibleItemId(), this.getLastVisibleItemId()]
     if( this.focusedItem < visibleRange[0] || this.focusedItem > visibleRange[1] )
     {
      this.focusedItem = visibleRange[0];
     }
     else if( this.focusedItem > 0 )
     {
       this.focusedItem--;
     }

     return this.focus(this.focusedItem, 0.2, 0.0);
   },

   focus : function(itemId, duration, delay )
   {
      if( itemId < 0 )
        itemId = 0;
      if( itemId >= this.item.length )
        itemId = this.item.length-1;

      this.isFocused = true;
      this.focusedItem = itemId;
      var itemPosition = this.getPosition(this.focusedItem, this.currentScrollPosition);
      var stageSize = dali.stage.getSize();
      if( itemPosition[0] < 0.0 )
      {
        this.scroll( -itemPosition[0], 0.3, 0.05, itemId+1 );
      }
      else if( itemPosition[0] + this.itemSize[0] > stageSize.x )
      {
        var amount = this.itemSize[0] - (stageSize.x - itemPosition[0]);
        this.scroll( -amount, 0.3, 0.05, itemId-1 );
      }
      return this.item[this.focusedItem];
   },

   focusedActor : function()
   {
     return this.item[this.focusedItem];
   },

   enablePanGetureDetection : function()
   {
     this.panGestureDetector = new dali.PanGestureDetector();
     if(this.panGestureDetector)
     {
       this.panGestureDetector.attach(this.itemRoot);
       this.panGestureDetector.on("panDetected", this.onPan );
     }
   },

   onPan : function(actor, panGesture)
   {
     if (panGesture.state == "started")
     {
       var found = false;
       for( i=0; i<result.item.length; ++i )
       {
         if( actor.name.localeCompare(result.item[i].name) == 0 )
         {
           result.baseItem = i;
           found = true;
           break;
         }
       }
       if( found == false )
       {
         result.baseItem = result.focusedItem;
       }
       result.scrollDisplacementX = 0.0;
       result.scrollDisplacementY = 0.0;
     }
     else if (panGesture.state == "continuing")
     {
       result.scrollDisplacementX = panGesture.displacement.x;
       result.scrollDisplacementY = panGesture.displacement.y;
       result.scrollcontinue(result.scrollDisplacementX, 0.3, 0.05, result.baseItem);
     }
     else if (panGesture.state == "finished")
     {
       var absScrollDistanceX = result.scrollDisplacementX;
       if(absScrollDistanceX < 0)
         absScrollDistanceX = 0 - absScrollDistanceX;

       var absScrollDistanceY = result.scrollDisplacementY;
       if(absScrollDistanceY < 0)
         absScrollDistanceY = 0 - absScrollDistanceY;

       var scrollSpeed = panGesture.velocity.x * panGesture.velocity.x + panGesture.velocity.y * panGesture.velocity.y;
       var maxScrollSpeed = 40.0;  // TBD
       if(scrollSpeed > maxScrollSpeed)
         scrollSpeed = maxScrollSpeed;

       if (absScrollDistanceX > 1.0 && scrollSpeed > 0.05) // Threshold TBD
       {
         if(result.scrollDisplacementX > 0.0) // scroll constant distance in constant speed.
         {
           result.scroll(dali.stage.getSize().x * 0.3, 0.5, 0.05, result.getFirstVisibleItemId(), true);
         }
         else
         {
           result.scroll(-dali.stage.getSize().x * 0.3, 0.5, 0.05, result.getLastVisibleItemId(), true);
         }
       }
       else if (absScrollDistanceY > 1.0 && scrollSpeed > 0.05) // Threshold TBD
       {
         if(result.scrollDisplacementY > 0.0) // scroll constant distance in constant speed.
         {
           if( result.fridgeApp.isMenuVisible )
           {
             result.fridgeApp.hideMenu();
           }
         }
         else
         {
           if( !result.fridgeApp.isMenuVisible )
           {
             result.fridgeApp.showMenu();
           }
         }
       }
     }
   },

   onHover : function(actor, hoverEvent)
   {
      if (hoverEvent.points[0].state == "motion")
      {
        for( i=0; i<result.item.length; ++i )
        {
          if( actor.name.localeCompare(result.item[i].name) == 0 )
          {
            //Find scrollView
            for(j=0;j<scrollViewInstanceCount;++j)
            {
              var length = scrollViewInstance[j].name.length;
              if( actor.name.length > length && actor.name.substring(0,length).localeCompare(scrollViewInstance[j].name) == 0 )
              {
                scrollViewInstance[j].isFocused = true;
              }
              else
              {
                scrollViewInstance[j].isFocused = false;
              }
            }

            result.focusedItem = i;
            actor.setKeyboardFocusable(true);
            dali.keyboardFocusManager.setCurrentFocusActor(actor);
            break;
          }
        }
      }
      return true;
   }
 }

  scrollViewInstance[scrollViewInstanceCount] = result;
  scrollViewInstanceCount++;

  return result;
}

