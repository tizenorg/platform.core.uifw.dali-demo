
var applicationInstance;

exports.New = function( application, position, size, backgroundImageUrl, iconImageUrl, iconSize, circleDefaultRadius, dali )
{
  var result =
  {
    "actor": new dali.Control("ImageView"),
    "showAnimation":null,
    "hideAnimation":null,
    "circleDefaultRadius":circleDefaultRadius,
    "arrow":new dali.Control("ImageView"),
    "visible":false,

    show : function(duration,delay)
    {
      var progress = 0.0;
      if( this.hideAnimation )
      {
        progress = this.hideAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0-progress;

        this.hideAnimation.stop();
      }
      this.showAnimation = new dali.Animation(duration);
      var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:delay, duration:duration};

      this.showAnimation.animateTo( this.actor, "uCircleRadius", 1.0, animOptions );
      this.showAnimation.animateTo( this.actor, "uColor", [1.0,1.0,1.0,1.0], animOptions );

      animOptions = { alpha:dali.ALPHA_FUNCTION_LINEAR, delay:delay, duration:duration*0.5};
      this.showAnimation.animateTo( this.arrow, "colorAlpha", 0.0, animOptions );
      this.showAnimation.setSpeedFactor(1.0);
      this.showAnimation.playFrom(progress);

      this.visible = true;
    },

    hide : function(duration,delay)
    {
      var progress = 0.0;
      if( this.showAnimation )
      {
        progress = this.showAnimation.getCurrentProgress();
        if( progress > 0.0 )
          progress = 1.0-progress;

        this.showAnimation.stop();
      }
      this.hideAnimation = new dali.Animation(duration);
      var animOptions = { alpha:dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE, delay:delay, duration:duration};

      var keyFramesRadius = [{progress:0.0, value: 1.0},{progress:1.0, value:this.circleDefaultRadius }];
      var keyFramesColor = [{progress:0.0, value: [1.0,1.0,1.0,0.0]},{progress:1.0, value:[0.0,0.0,0.0,0.0]}];

      this.hideAnimation.animateTo( this.actor, "uCircleRadius", circleDefaultRadius, animOptions );
      this.hideAnimation.animateTo( this.actor, "uColor", [0.0,0.0,0.0,1.0], animOptions );

      animOptions = { alpha:dali.ALPHA_FUNCTION_LINEAR, delay:delay, duration:duration};
      this.hideAnimation.animateTo( this.arrow, "colorAlpha", 1.0, animOptions );
      this.hideAnimation.setSpeedFactor(1.0);
      this.hideAnimation.playFrom(progress);

      this.visible = false;
    },

    arrowTouchedEvent : function(actor, touchEvent)
    {
      if (touchEvent.points[0].state == "down")
      {
        applicationInstance.showMenu();
      }
      return true;
    }
  }

  result.actor.parentOrigin = dali.TOP_LEFT;
  result.actor.anchorPoint = dali.TOP_LEFT;
  result.actor.size = size;
  result.actor.position = position;

  result.actor.registerAnimatableProperty("uColor",[0.0,0.0,0.0,0.0]);
  result.actor.registerAnimatableProperty("uSize",size);
  result.actor.registerAnimatableProperty("uCircleRadius",result.circleDefaultRadius);
  result.actor.registerAnimatableProperty("uCircleCenter",[0.5, ((0.5*size[1])/size[0]) + 0.5]);

var vertShader =
      "attribute vec3 aPosition;\
       attribute vec2 aTexCoord;\
       varying vec2 vTexCoord;\
       uniform mat4 uModelView;\
       uniform mat4 uProjection;\
       uniform lowp vec3 uSize;\
       uniform lowp vec2 uCircleCenter;\
       varying lowp vec2 vPointToCenter;\
       void main()\
       {\
         vTexCoord = vec2( aPosition.x + 0.5, aPosition.y + 0.5 );\
         gl_Position = uProjection * uModelView * ( vec4(aPosition, 1.0) * vec4(uSize, 1.0) );\
         vPointToCenter = vec2(vTexCoord.x,(uSize.y/uSize.x)*vTexCoord.y + (abs(uSize.x-uSize.y)*0.5)/uSize.x) -  uCircleCenter;\
       }"
 
  var fragShader =
      "uniform lowp float uCircleRadius;\
       varying lowp vec2 vPointToCenter;\
       varying lowp vec2 vTexCoord;\
       uniform sampler2D sTexture;\
       uniform lowp vec4  uColor;\
       void main()\
       {\
         lowp float distanceToSphere = sqrt(dot(vPointToCenter,vPointToCenter)) - uCircleRadius;\
         lowp float alpha = min(0.5,-distanceToSphere*1000.0 + 1.0);\
         if(alpha < 0.0) discard;\
         gl_FragColor = vec4( texture2D( sTexture, vTexCoord ).xyz * uColor.xyz, alpha);\
       }"

  var shader = {
      "vertexShader" : vertShader,
      "fragmentShader": fragShader,
      "hints" : "outputIsTransparent"
  };

  var backgroundImage = {
      "rendererType" : "image",
      "imageUrl"   : backgroundImageUrl,
      "shader" : shader
  };

  result.actor.image = backgroundImage;

  result.arrow.image = iconImageUrl;

  result.arrow.parentOrigin = dali.BOTTOM_CENTER;
  result.arrow.anchorPoint = dali.BOTTOM_CENTER;
  result.arrow.size = iconSize;
  result.actor.add(result.arrow);
  result.arrow.on("touched", result.arrowTouchedEvent);

  instance = result;
  applicationInstance = application;

  return result;
}
