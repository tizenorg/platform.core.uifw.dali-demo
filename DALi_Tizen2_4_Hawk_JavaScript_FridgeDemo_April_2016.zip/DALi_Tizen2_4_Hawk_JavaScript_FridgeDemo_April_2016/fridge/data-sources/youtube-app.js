
var youTubeAPI = require('./youtube-data.js');

function YouTubeApp( )// constructor
{

    var LAYOUT =
    {
        rowSpacing:40,
        thumbPosition:[10,50,0],
        titlePosition:[200,40,0],
       // shrink thumbnail to 66%
        thumbSize:[320*(2/3),180*(2/3),1]
    };

    this.mycallback = function( dali, data )
    {
        console.log(data);
        var object = JSON.parse(data);
        var videos = object.items;
        // add a delay to the fade on for each animation
        var animOptions = {
            alpha: dali.ALPHA_FUNCTION_EASE_IN_OUT_SINE,
            delay: 0,
            duration: 1.0,
        };

        for( i = 0; i< videos.length;++i)
        {
            video = videos[i].snippet;
            console.log( video.title);
            console.log( video.thumbnails.medium.url);

            var container = this.items[i];
            // should really switch to get child by name
            var thumbnail = container.getChildAt(0);
            var titleContainer = container.getChildAt(1);
            var title = titleContainer.getChildAt(0);

            thumbnail.image = video.thumbnails.medium.url;
            title.text = video.title;

            container.color = [ 1, 1, 1, 0];
            var anim = new this.dali.Animation( 1 );
            anim.animateBy( container, "color", [ 1, 1, 1, 1] , animOptions);
            animOptions.delay +=0.2; // delay by 1/3 second to account for loading time
            anim.play();
        }

    };
    this.search = function( dali, keyword  )
    {

        // use https://developers.google.com/youtube/v3/docs/search/list#try-it
        // for testing out what options you want to set
        var searchOptions = {
            q:keyword,
            maxResults:this.numberItems,
            type:'video'//,
           // location:'37.263573,127.028601', //Suwon
          //  locationRadius:'30km'
        }
        //console.log("searching");
        // create a closure
        var that = this;

        youTubeAPI.search( searchOptions, this.proxy, function(data)  {
            that.mycallback(dali, data);
            });
    };

    this.createItem = function()
    {
        // just create a thumbnail for now and title
        var container = new this.dali.Actor();
        container.parentOrigin = this.dali.TOP_LEFT;
        container.anchorPoint = this.dali.TOP_LEFT;

        var thumbnail = new this.dali.Control("ImageView");

        thumbnail.parentOrigin = this.dali.TOP_LEFT;
        thumbnail.anchorPoint = this.dali.TOP_LEFT;
        thumbnail.position= LAYOUT.thumbPosition; // inset
        thumbnail.size = LAYOUT.thumbSize;
        thumbnail.name = "thumbnail";

        var titleContainer = new this.dali.Actor();
        titleContainer.parentOrigin = this.dali.TOP_LEFT;
        titleContainer.anchorPoint = this.dali.TOP_LEFT;
        titleContainer.positionX = LAYOUT.thumbSize[0] + 20;
        titleContainer.positionY = LAYOUT.thumbPosition[1];
        titleContainer.size = LAYOUT.thumbSize; // currently use same size as thumbnail for text

        var title = new this.dali.Control("TextLabel");
        title.fontFamily ="HelveticaNeue";
        title.fontStyle = "Bold";

        title.parentOrigin = this.dali.TOP_LEFT;
        title.anchorPoint = this.dali.TOP_LEFT;
        title.textColor = [0.1,0.1,0.1,1.0]; //grey
        title.multiLine = true;
        title.widthResizePolicy = "FILL_TO_PARENT";
        title.heightResizePolicy = "DIMENSION_DEPENDENCY";
        title.pointSize = 20;

        title.name = "title";
        titleContainer.add( title );

        container.add( thumbnail );
        container.add( titleContainer );

        return container;
    }
    this.createItemList = function()
    {
        this.items = [];
        var yPos = 0;
        for( var i = 0; i < this.numberItems; ++i )
        {
            var item = this.createItem(i);
            item.positionY = yPos;
            this.placeHolder.add( item );
            this.items.push( item );
            yPos+=LAYOUT.thumbSize[1] + LAYOUT.rowSpacing;
        }
    }

    this.createUI =function ( daliObject, internetProxy, imageDir )
    {
       this.numberItems = 5;
       this.dali = daliObject;
       this.proxy = internetProxy;
       this.placeHolder = new this.dali.Control("ImageView");
       this.placeHolder.image = imageDir + "white-pixel.png";
       this.placeHolder.positionY = 10;

       var logoActor = new this.dali.Control("ImageView");
       logoActor.image = imageDir + "youtube.png";
       logoActor.parentOrigin = this.dali.TOP_LEFT;
       logoActor.anchorPoint = this.dali.TOP_LEFT;
       logoActor.positionX = 20;
       logoActor.size = [100.0, 50.0, 1.0];
       this.placeHolder.add( logoActor );

       this.createItemList();

       return this.placeHolder;
    };
};

// may youtube app a singleton so any other JavaScript file can use it
module.exports = new YouTubeApp();
