// Fridge demo application
//var youTube = require('./data-sources/youtube-app.js')
//var youKu = require('./data-sources/youku-app.js')

// If using a proxy set the ip address here
var internetProxy = "http://106.1.18.35:8080"
// var internetProxy = ""

var window= {
       x:0,
       y:0,
       width:1920,
       height: 1080,
       transparent: false,
       name:'dali-fridge-app'
 };

var viewMode={
       'stereoscopicMode':'mono', // stereo-horizontal, stereo-vertical, stereo-interlaced,
       'stereoBase': 65 // Distance in millimeters between left/right cameras typically between (50-70mm)
 };

var options= {
       'window': window,
       'viewMode': viewMode,
 }

//var dali = require('../build/Release/dali')( options );
var dali = require('dali')( options );

var imageDir = "./images/";
var scriptDir = "./scripts/";

var fridgeApp = { };

var button1;
var button2;

var itemView;

/**
 * Initialises the image paths and creates a builder for loading JSON
 * @method init
 */
fridgeApp.init = function()
{
  console.log("Image directory is : " + imageDir);
  console.log("JSON Script directory is : " + scriptDir);

  this.builder = new dali.Builder();
  this.builder.addConstants({
      IMAGE_PATH: imageDir,
      SCRIPT_PATH: scriptDir
  });

  this.builder.loadFromFile(scriptDir + "main-screen.json");
}

fridgeApp.createBackground = function( fileName )
{
  // create a background image
  var stageSize = dali.stage.getSize();
  this.stageSize = [stageSize.x, stageSize.y, 1];

  var background = new dali.Control("ImageView");
  background.image = imageDir + fileName;

  background.parentOrigin = dali.TOP_LEFT;
  background.anchorPoint = dali.TOP_LEFT;
  background.position = [0.0,0.0,-4.0];
  background.size = [stageSize.x,stageSize.y,0.0];

  //Add background to the stage
  dali.stage.add( background );
}

fridgeApp.createPosters = function()
{
  //Create scroll view
  var scrollviewFactory = require("./scrollview.js");
  var stageSize = dali.stage.getSize();

  var itemSize = [stageSize.x/4.0, stageSize.y * 0.85,0.0];
  this.posters = scrollviewFactory.New("Posters", itemSize, 0.0, dali, fridgeApp);
  this.posters.root.position = [0.0,stageSize.y * 0.15,-2.0];
  dali.stage.add( this.posters.root );

  for(var i = 0; i < 4; i++)
  {

   /* if( i == 0)
    {
      // to do we can pass in search options here?
      var item = youTube.createUI( dali, internetProxy, imageDir );
      youTube.search("films");
      this.posters.addItem( item );
    }
    else*/
    {

    var item = new dali.Control("ImageView");
    item.image = imageDir + "item0.ktx";
    this.posters.addItem(item);
    }

    item = new dali.Control("ImageView");
    item.image = imageDir + "item1.ktx";
    this.posters.addItem(item);

    item = new dali.Control("ImageView");
    item.image = imageDir + "item2.ktx";
    this.posters.addItem(item);

    item = new dali.Control("ImageView");
    item.image = imageDir + "item3.ktx";
    this.posters.addItem(item);

    item = new dali.Control("ImageView");
    item.image = imageDir + "item4.ktx";
    this.posters.addItem(item);

    item = new dali.Control("ImageView");
    item.image = imageDir + "item5.ktx";
    this.posters.addItem(item);
  }

  this.posters.itemRoot.size = [stageSize.x,stageSize.y*0.85,0.0];
  this.posters.itemRoot.parentOrigin = dali.TOP_LEFT;
  this.posters.itemRoot.anchorPoint = dali.TOP_LEFT;
  this.posters.itemRoot.name = "posters";
}

fridgeApp.createBanner = function()
{
  //Create banner
  var stageSize = dali.stage.getSize();
  var image = imageDir + "banner.png";
  var bannerFactory = require("./banner.js");
  this.banner = bannerFactory.New(image,[0.0,0.0,-3.0],[stageSize.x,stageSize.y*0.15,0], dali);

  dali.stage.add( this.banner.root );

}

function scalePointSize( pointSize )
{
  var dpi = dali.stage.getDpi();
  var meanDpi = (dpi.x + dpi.y) * 0.5;
  return pointSize * 220 / meanDpi;
}

function createMenuItem( itemSize, iconName, title, fontSize )
{
  fridgeApp.builder.addConstants({
      MENU_ITEM_SIZE_X:itemSize[0],
      MENU_ITEM_SIZE_Y:itemSize[1],

      MENU_ITEM_ICON: iconName,
      MENU_ITEM_TITLE: title
  });

  var item = fridgeApp.builder.create({template: "template-menu-item"});
  var icon = item.findChildByName("icon");
  icon.size = [itemSize[0]*0.5,itemSize[0]*0.5,0.0];
  icon.position = [0.0,-itemSize[1]*0.1,0.0];

  var text = icon.findChildByName("title");
  text.position = [0.0,itemSize[0]*0.1,0.0];

  var line = item.findChildByName("line");
  line.size = [1.0,itemSize[1],0.0];

  return item;
}

fridgeApp.createMenu = function()
{
  var stageSize = dali.stage.getSize();
  var scrollviewFactory = require("./scrollview.js");
  var itemSize = [stageSize.x/8.0,stageSize.y*0.25,0.0];
  this.menu = scrollviewFactory.New("Menu", itemSize, 0.0, dali, fridgeApp);
  this.menu.root.position = [0,stageSize.y*0.75,0.0];
  dali.stage.add( this.menu.root );

  for(var i = 0; i < 10; i++)
  {
    var menuItem = createMenuItem(itemSize,"icon0.png","Weather",18);
    this.menu.addItem(menuItem);

    menuItem = createMenuItem(itemSize,"icon1.png","Quotes",18);
    this.menu.addItem(menuItem);

    menuItem = createMenuItem(itemSize,"icon2.png","Movie",18);
    this.menu.addItem(menuItem);
  }

  this.menu.hide(stageSize.y*0.25,0.0,0.0);

  //Create menu background effect
  var menuBackgroundfactory = require("./menubackground.js");
  var imageUrl = imageDir + "white-pixel.png";
  var iconUrl = imageDir + "arrow.png";

  this.menu.background = menuBackgroundfactory.New(fridgeApp, [0.0,stageSize.y*0.75,-1.0],[stageSize.x,stageSize.y*0.25,0.0], imageUrl, iconUrl, [stageSize.x*0.02,stageSize.y*0.025,0.0], 0.02, dali );
  dali.stage.add( this.menu.background.actor );

  this.isMenuVisible = false;

  this.menu.itemRoot.size = [stageSize.x,stageSize.y*0.25,0.0];
  this.menu.itemRoot.parentOrigin = dali.TOP_LEFT;
  this.menu.itemRoot.anchorPoint = dali.TOP_LEFT;
  this.menu.itemRoot.name = "menu";
}

function startup()
{
  fridgeApp.init();
  dali.stage.on("keyEvent", fridgeApp.stageKeyEvent);
  dali.keyboardFocusManager.on("keyboardPreFocusChange", fridgeApp.preFocusChanged);
  fridgeApp.createBackground("background.png");

  fridgeApp.createPosters();
  fridgeApp.createBanner();
  fridgeApp.createMenu();
}

fridgeApp.showMenu = function()
{
  var stageSize = dali.stage.getSize();
  var postersViewSize = [stageSize.x, (stageSize.y*0.8)*0.85,0.0];
  var itemSize = [(stageSize.x/4.0)*0.85, (stageSize.y*0.8)*0.85,0.0];
  var posterPositionY = 0.15*stageSize.y - (0.75-0.8*0.85)*stageSize.y*0.5;
  fridgeApp.posters.expand(-posterPositionY, postersViewSize, itemSize, 0.5, 0.0);
  fridgeApp.banner.hide(0.2,0.0);

  fridgeApp.menu.background.show(1.0,0.3);
  fridgeApp.menu.show(0.5,0.8,0.05);
  fridgeApp.isMenuVisible = true;
  fridgeApp.isFocusInPosters = false;
  fridgeApp.menu.focus(0,0.0,0.0);
}

fridgeApp.hideMenu = function()
{
  var stageSize = dali.stage.getSize();
  fridgeApp.menu.background.hide(1.0,0.0);
  fridgeApp.menu.hide(stageSize.y*0.25,0.5,0.0);

  var postersViewSize = [stageSize.x, stageSize.y*0.85, 0.0];
  var itemSize = [(stageSize.x/4.0), (stageSize.y*0.85),0.0];
  fridgeApp.posters.expand(0, postersViewSize, itemSize, 0.5, 0.8);
  fridgeApp.banner.show(0.2,0.8);
  fridgeApp.isMenuVisible = false;
  fridgeApp.isFocusInPosters = true;
}

fridgeApp.stageKeyEvent = function(keyEvent) {
  if( keyEvent.state == "up" )
    return;

 console.log("KEY = " + keyEvent.keyDescription );


  switch (keyEvent.keyDescription)
  {
    case "BackSpace":
    case "XF86Back":
    case "Escape":
    {
      if( fridgeApp.isMenuVisible )
      {
        fridgeApp.hideMenu();

        if(fridgeApp.posters.isFocused == false )
        {
          fridgeApp.posters.focus(fridgeApp.posters.focusedItem);
          fridgeApp.posters.isFocused = true;
        }
      }
      //process.exit(0);
      break;
    }
    case "XF86AudioForward":
    case "XF86AudioNext":
    case "XF86LowerChannel":
    case "Next":
    {
      if(fridgeApp.posters.isFocused == true )
      {
        fridgeApp.posters.scroll( -dali.stage.getSize().x, 1.0, 0.05, fridgeApp.posters.getFirstVisibleItemId());
      }
      else if(fridgeApp.menu.isFocused == true )
      {
        fridgeApp.menu.scroll( -dali.stage.getSize().x, 1.0, 0.05,  fridgeApp.menu.getFirstVisibleItemId());
      }
      break;
    }
    case "XF86AudioRewind":
    case  "XF86RaiseChannel":
    case "Prior":
    {
      if(fridgeApp.posters.isFocused == true )
      {
        fridgeApp.posters.scroll( dali.stage.getSize().x, 1.0, 0.05, fridgeApp.posters.getLastVisibleItemId());
      }
      else if(fridgeApp.menu.isFocused == true )
      {
        fridgeApp.menu.scroll( dali.stage.getSize().x, 1.0, 0.05, fridgeApp.menu.getLastVisibleItemId());
      }
      break;
    }
  }
}

fridgeApp.preFocusChanged = function(currentFocusedActor, proposedActorToFocus, direction)
{
  if (direction == "up" )
  {
    if(fridgeApp.posters.isFocused == false)
    {
        fridgeApp.posters.isFocused = true;
        return fridgeApp.posters.focus(fridgeApp.posters.getFirstVisibleItemId(),0.0,0.0);
    }
  }
  else if (direction == "down")
  {
      if(fridgeApp.posters.isFocused == true)
      {
        if( fridgeApp.isMenuVisible == false )
        {
          fridgeApp.showMenu();
        }
        else
        {
          fridgeApp.menu.focus(fridgeApp.menu.getFirstVisibleItemId(),0.0,0.0);
        }

        fridgeApp.posters.isFocused = false;
        return fridgeApp.menu.focusedActor();
      }
  }
  else if (direction == "left")
  {
    if( fridgeApp.posters.isFocused == true )
    {
      return fridgeApp.posters.focusPrev();
    }
    else
    {
      return fridgeApp.menu.focusPrev();
    }
  }
  else if (direction == "right")
  {
    if( fridgeApp.posters.isFocused == true )
    {
      return fridgeApp.posters.focusNext();
    }
    else
    {
      if( fridgeApp.isMenuVisible == true)
      {
        return fridgeApp.menu.focusNext();
      }
      else
      {
       fridgeApp.posters.isFocused = true;
      }
    }
  }

  return currentFocusedActor;
}

var currentSearchIndex = 1; // we start at 0;
var currentKeyIndex = 0;
setInterval(function() {
return;
var key ={
keyDescription:""
};

var keyIndex;
do {
  keyIndex = Math.round( Math.random() * 4 );
} while ( (keyIndex == currentKeyIndex)
          || (!fridgeApp.isMenuVisible && keyIndex == 2)
          || (fridgeApp.posters.isFocused && fridgeApp.posters.getFirstVisibleItemId() == 0 && keyIndex == 1)
          || (fridgeApp.posters.isFocused && keyIndex == 3)
          || (!fridgeApp.posters.isFocused && keyIndex == 4) 
        );

currentKeyIndex = keyIndex;

if( keyIndex == 0)
{
 key.keyDescription="Next";
 fridgeApp.stageKeyEvent( key );
}
else if ( keyIndex == 1)
{
 key.keyDescription="Prior";
 fridgeApp.stageKeyEvent( key );
}
if( keyIndex == 2)
{
 key.keyDescription="Escape";
 fridgeApp.stageKeyEvent( key );
}
if( keyIndex == 3)
{
    if(fridgeApp.posters.isFocused == false)
    {
        fridgeApp.posters.isFocused = true;
        return fridgeApp.posters.focus(fridgeApp.posters.getFirstVisibleItemId(),0.0,0.0);
    }
}
if( keyIndex == 4)
{
    if(fridgeApp.posters.isFocused == true)
    {
      if( fridgeApp.isMenuVisible == false )
      {
        fridgeApp.showMenu();
      }
      else
      {
        fridgeApp.menu.focus(fridgeApp.menu.getFirstVisibleItemId(),0.0,0.0);
      }

      fridgeApp.posters.isFocused = false;
    }
}


/*
var searchTerms = [
  "Films",
  "cats",
  "breaking News",
  "Latest Sport",
  "Minecraft"
]

 youTube.search( dali, searchTerms[currentSearchIndex]);
 currentSearchIndex++;
 if( currentSearchIndex === searchTerms.length )
 {
  currentSearchIndex=0;
 }*/


}, 3000);


startup();
fridgeApp.showMenu();

