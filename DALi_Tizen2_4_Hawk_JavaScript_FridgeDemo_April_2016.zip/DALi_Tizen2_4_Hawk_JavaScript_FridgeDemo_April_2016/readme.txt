Demo was running on the following image.

Model=T-HKPTDEUC;
Version=T-HKPTDEUC-0624.30;
Build=tztv-2.4-main2016-hawk-p_20160324.3;


To execute it... copy fridge demo into 
/usr/lib/node/examples   

then type
node fridge-app.js

If the fridge demo is else where it's not run for security reasons
